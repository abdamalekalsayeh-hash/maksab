// ضع بيانات مشروع Supabase هنا فقط.
// استخدم Project URL و Publishable key من لوحة Supabase.
// لا تضع service_role key هنا أبدًا.
const SUPABASE_URL = "https://YOUR-PROJECT.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "YOUR-PUBLISHABLE-KEY";

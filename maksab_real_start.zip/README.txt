مكسب — بداية النسخة الحقيقية

1) أنشئ مشروع Supabase.
2) افتح SQL Editor والصق schema.sql ثم Run.
3) من Project Settings / API خذ Project URL و Publishable key.
4) ضع القيم في config.js.
5) ارفع index.html وconfig.js إلى مستودع GitHub Pages.
6) اختبر إنشاء حساب، إضافة خدمة، ثم طلب خدمة من حساب آخر.

مهم:
- لا تضع service_role key في GitHub أو داخل المتصفح.
- المدفوعات والأرصدة المالية الحقيقية لم تُفعّل بعد.
- لا تعتبر رصيدًا حقيقيًا حتى نضيف وسيلة دفع وتسوية آمنة في خادم.


create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role text not null default 'user' check (role in ('user','admin')),
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name','مستخدم'));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  category text not null,
  description text not null,
  price numeric(12,2) not null check (price > 0),
  status text not null default 'active' check (status in ('active','paused','removed')),
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  buyer_id uuid not null references public.profiles(id) on delete cascade,
  seller_id uuid not null references public.profiles(id) on delete cascade,
  service_id uuid not null references public.services(id) on delete restrict,
  price numeric(12,2) not null check (price > 0),
  status text not null default 'pending' check (status in ('pending','accepted','completed','cancelled')),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.services enable row level security;
alter table public.orders enable row level security;

drop policy if exists "profiles own read" on public.profiles;
create policy "profiles own read" on public.profiles
for select to authenticated using (id = auth.uid());

drop policy if exists "active services public read" on public.services;
create policy "active services public read" on public.services
for select using (status = 'active');

drop policy if exists "seller create service" on public.services;
create policy "seller create service" on public.services
for insert to authenticated with check (seller_id = auth.uid());

drop policy if exists "seller update own service" on public.services;
create policy "seller update own service" on public.services
for update to authenticated using (seller_id = auth.uid()) with check (seller_id = auth.uid());

drop policy if exists "buyer read own orders" on public.orders;
create policy "buyer read own orders" on public.orders
for select to authenticated using (buyer_id = auth.uid());

drop policy if exists "seller read own orders" on public.orders;
create policy "seller read own orders" on public.orders
for select to authenticated using (seller_id = auth.uid());

create or replace function public.create_order(p_service_id uuid)
returns uuid
language plpgsql
security definer set search_path = public
as $$
declare
  s public.services;
  new_id uuid;
begin
  select * into s from public.services where id = p_service_id and status = 'active';
  if not found then raise exception 'الخدمة غير متاحة'; end if;
  if s.seller_id = auth.uid() then raise exception 'لا يمكنك طلب خدمتك الخاصة'; end if;
  insert into public.orders (buyer_id,seller_id,service_id,price)
  values (auth.uid(),s.seller_id,s.id,s.price)
  returning id into new_id;
  return new_id;
end;
$$;

grant execute on function public.create_order(uuid) to authenticated;

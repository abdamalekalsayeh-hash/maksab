-- بعد تشغيل schema.sql
-- استبدل البريد أدناه ببريد حسابك في Supabase ثم شغّل هذا الملف مرة واحدة.
update public.profiles
set role = 'admin'
where id = (select id from auth.users where email = 'ضع-بريدك-هنا');

create or replace function public.admin_check()
returns boolean
language plpgsql
security definer set search_path=public
as $$
begin
  return exists(select 1 from public.profiles where id=auth.uid() and role='admin');
end;
$$;
revoke all on function public.admin_check() from public;
grant execute on function public.admin_check() to authenticated;

create or replace function public.admin_dashboard()
returns jsonb
language plpgsql
security definer set search_path=public
as $$
declare result jsonb;
begin
  if not public.admin_check() then raise exception 'غير مصرح'; end if;
  select jsonb_build_object(
    'users_count',(select count(*) from public.profiles),
    'services_count',(select count(*) from public.services),
    'orders_count',(select count(*) from public.orders),
    'services',coalesce((select jsonb_agg(jsonb_build_object('title',s.title,'category',s.category,'price',s.price,'status',s.status,'seller_name',coalesce(p.full_name,'مستخدم')) order by s.created_at desc) from public.services s left join public.profiles p on p.id=s.seller_id),'[]'::jsonb),
    'orders',coalesce((select jsonb_agg(jsonb_build_object('service_title',coalesce(s.title,'خدمة'),'buyer_name',coalesce(bp.full_name,'مستخدم'),'seller_name',coalesce(sp.full_name,'مستخدم'),'price',o.price,'status',o.status) order by o.created_at desc) from public.orders o left join public.services s on s.id=o.service_id left join public.profiles bp on bp.id=o.buyer_id left join public.profiles sp on sp.id=o.seller_id),'[]'::jsonb)
  ) into result;
  return result;
end;
$$;
revoke all on function public.admin_dashboard() from public;
grant execute on function public.admin_dashboard() to authenticated;

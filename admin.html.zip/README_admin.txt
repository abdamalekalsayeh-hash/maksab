لوحة إدارة مكسب

1) ارفع admin.html إلى مستودع GitHub نفسه بجانب index.html وconfig.js.
2) افتح Supabase > SQL Editor.
3) في admin.sql استبدل "ضع-بريدك-هنا" ببريد حسابك الذي سجلت به.
4) الصق admin.sql كاملًا واضغط Run.
5) افتح:
https://abdamalekalsayeh-hash.github.io/maksab/admin.html
6) سجّل دخولك بنفس حساب المدير.

مهم: لا تضع Secret key أو service_role key داخل GitHub.
